<?php
// Log errors to file instead of suppressing them or showing on screen
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', '/tmp/weewx_php_errors.log');

// sun moon planets almanac


$alm["sun_altitude"] = 57.16703677144962;
if ($alm["sun_altitude"] < 0)
{
$alm["sun_None"] = "<i>(Always down)</i>";
$alm["daylight_str"] = "00:00";
}
else
{
$alm["sun_None"] = "<i>(Always up)</i>";
$alm["daylight_str"] = "24:00";
}
$alm["parallacticAngle"] = -18.04197448001858;
$alm["ecliptic_longitude_moon"] = 285.1149496749505;
$alm["ecliptic_latitude_moon"] = -3.632701300685851;
$alm["ecliptic_longitude_sun"] = 98.45909007531202;
$alm["moon_ecliptic_angle"] = 186.65585959963846;
$alm["ecliptic_angle"] = 23.435845713056494;
$alm["moon_distance"] = 404496.21570732864;
$alm["sun_distance"] = 152076448.682875;
$alm["moon_azimuth"] = 26.685666889464393;
$alm["moon_altitude"] = -62.77954806077243; 
$alm["sun_azimuth"] = 216.59328727971644;
$alm["sunrise"] = "04:47:32";
$alm["sunset"] = "21:27:25";
$alm["sunrise_date"] = "Jun 30 2026 04:47:32";
$alm["sunset_date"] = "Jun 30 2026 21:27:25";
$alm["sun_right_ascension"] = 99.56136688651952;
$alm["sun_geo_right_ascension"] = 99.56187842318792;
$alm["sun_declination"] = 23.1455042141232;
$alm["sun_geo_declination"] = 23.146682083495023;
$alm["moon_right_ascension"] = 286.86188520436707;
$alm["moon_geo_right_ascension"] = 286.7189576499855;
$alm["moon_declination"] = -26.629125580197897;
$alm["moon_geo_declination"] = -26.23957237065319;
$alm["next_vernal_equinox"] = "20/03/27 20:24:41";
$alm["next_autumnal_equinox"] = "23/09/26 01:05:13";
$alm["next_equinox"] = "23/09/26 01:05:13";
$alm["next_solstice"] = "21/12/26 20:50:14";
$alm["sidereal_time"] = 120.14710836672123;
$alm["civil_twilight_begin"] = "03:59";
$alm["civil_twilight_end"] = "22:15";
$alm["nautical_twilight_begin"] = "02:43";
$alm["nautical_twilight_end"] = "23:30";
$alm["astronomical_twilight_begin"] = "   N/A";
$alm["astronomical_twilight_end"] = "   N/A";
$alm["sun_meridian_transit"] = "13:07";
$alm["moon_meridian_transit"] = "01:09";
$alm["moonphase"] = "Full";
$alm["moonPhase"] = $lang['Fullmoon'] ?? $alm["moonphase"];
$alm["moon_age"] = 15.441549602895975;
$alm["hour_sun"] = 20.585741483660712;
$alm["hour_moon"] = 193.28522316581316;
$alm["luminance"] = 99.57723650947212;
$alm["fullmoon"] = "29 Jul 15:35";
$alm["newmoon"] = "14 Jul 10:43";   
$alm["daylight"] = "16:39";
$alm["moonrise"] = "22:22";
$alm["moonset"] = "04:33";
$alm["mercury_hlongitude"] = 255.38452741029033;
$alm["venus_hlongitude"] = 207.06403460300788;
$alm["earth_hlongitude"] = 278.78579500742194;
$alm["mars_hlongitude"] = 35.80695370212401;
$alm["jupiter_hlongitude"] = 124.08392255670668;
$alm["saturn_hlongitude"] = 8.023208319488061;
$alm["uranus_hlongitude"] = 61.968695725192404;
$alm["neptune_hlongitude"] = 2.4601174016463614;
$alm["pluto_hlongitude"] = 304.15741495295947;
// night or day?  guard against $alm keys being unset if almanac extras unavailable
if (strtotime(date("G.i")) >= strtotime($alm["civil_twilight_begin"] ?? '00:00') && strtotime(date("G.i")) < strtotime($alm["civil_twilight_end"] ?? '23:59'))
{
    $dayPartCivil = "day";
} else {
    $dayPartCivil = "night";
}
if (strtotime(date("G.i")) >= strtotime($alm["nautical_twilight_begin"] ?? '00:00') && strtotime(date("G.i")) < strtotime($alm["nautical_twilight_end"] ?? '23:59'))
{
    $dayPartNautical = "day";
} else {
    $dayPartNautical = "night";
}
if (strtotime(date("G.i")) >= strtotime($alm["sunrise"] ?? '00:00') && strtotime(date("G.i")) < strtotime($alm["sunset"] ?? '23:59'))
{
    $dayPartNatural = "day";
} else {
    $dayPartNatural = "night";
}
?>
