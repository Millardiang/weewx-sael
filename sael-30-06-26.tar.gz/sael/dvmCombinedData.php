<?php
include ('fixedSettings.php');
include ('dvmShared.php');
include ('common.php');
// Log errors to file instead of suppressing them or showing on screen
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', '/tmp/weewx_php_errors.log');

// Path to the JSON file - check both relative paths
$jsonFilePath = null;
$jsonCandidates = ['./.jsondata/loop.json', '../.jsondata/loop.json'];
foreach ($jsonCandidates as $candidate) {
    if (file_exists($candidate)) {
        $jsonFilePath = $candidate;
        break;
    }
}

// Load JSON data with graceful fallback  never die() so index.php can still render
$data = [];
$dataLoadError = null;
if ($jsonFilePath === null) {
    $dataLoadError = "JSON file not found in ./.jsondata/ or ../.jsondata/";
} else {
    $jsonData = @file_get_contents($jsonFilePath);
    if ($jsonData === false) {
        $dataLoadError = "Could not read JSON file at $jsonFilePath";
    } else {
        $decoded = json_decode($jsonData, true);
        if ($decoded === null) {
            $dataLoadError = "Failed to decode JSON from $jsonFilePath: " . json_last_error_msg();
        } else {
            $data = $decoded;
        }
    }
}
if ($dataLoadError !== null) {
    error_log("dvmCombinedData: $dataLoadError");
}

// Safe helper: read from $data['observations'], returning null if missing
function obsVal($key, $round = null) {
    global $data;
    $val = $data['observations'][$key] ?? null;
    if ($val === null) return null;
    return ($round !== null) ? round($val, $round) : $val;
}

// Safe number_format: returns formatted string or null if value is missing
function safeFormat($value, $decimals = 1) {
    if ($value === null || !is_numeric($value)) return null;
    return number_format($value, $decimals);
}

// general
$cardUpdated = strtotime($data["metadata"]["stats"]["last_update"]);
$sundial_time = date("M d Y H:i:s",filemtime('serverdata/dvmRealtime.txt'));        
$stationlocation = "Steeple Claydon, UK";
$hardware = " GW3000A_V1.2.1";
$lat = 51.94;
$lon = -0.987;
$absLat = abs($lat);
$absLon = abs($lon);
if ($lat >= "0"){$NS = "North";}
else {$NS = "South";}
if ($lon >= "0") {$EW = "East";}
else {$EW = "West";}
$elevation = 88.0;
$url = "https://claydonsweather.org.uk";
$divum["date"] = date($dateFormat, $divum["datetime"]);
$divum["time"] = date($timeFormat, $divum["datetime"]);
$divum["swversion"] = "5.4.0";
$divum["build"] = "RESPONSIVE";
$divum["since"] = date('M Y',1741954920);
$divum["heatmap_year"] = date("Y");
$stationUptime = "0 days, 21 hours, 25 minutes";
$dvmPath = "/var/www/html/sael";
$TS = time();
if($theme == 'dark') {$convertStyle = "background: 0; border-color: #393d40; color:";}
else {$convertStyle = "background:";}
$phpVersion = phpversion();



//air density
$air_density["current"] = obsVal('airDensity', 4);

//air quality
$aqi["pm1_0"] = $data["observations"]["pm1_0"] ?? null;
$aqi["pm2_5"] = $data["observations"]["pm2_5"] ?? null;
$aqi["pm4_0"] = $data["observations"]["pm4_0"]?? null;
$aqi["pm10_0"] = $data["observations"]["pm10_0"] ?? null;

//barometer
$barom["units"] = " hPa";
if ($barom["units"] == " inHg"){
    $barom["units"] = "inHg";
}
else if ($barom["units"] == " hPa")
{
    $barom["units"] = "hPa";
}
else if ($barom["units"] == " kPa")
{
    $barom["units"] = "kPa";
}
else if ($barom["units"] == " mmHg")
{
    $barom["units"] = "mmHg";
}
else if ($barom["units"] == " mbar")
{
    $barom["units"] = "mbar";
}
$barom["current"] = obsVal('barometer', 1);
$barom["max"] = 1025.50;
$barom["maxtime"] = date('H:i',"1782774766");
$barom["min"] = 1020.90;
$barom["mintime"] = date('H:i',"1782826072");
$barom["trend_code"] = round((float)"-1.6550", 0);
if(is_numeric($barom["trend_code"]) != 1){$barom["trend_code"] = 0;}
if($barom["trend_code"]>3){$barom["trend_desc"]="Rising Very Rapidly";$barom["trend_code"]=4;}
else if($barom["trend_code"]>2){$barom["trend_desc"]="Rising Quickly";$barom["trend_code"]=3;}
else if($barom["trend_code"]>1){$barom["trend_desc"]="Rising";$barom["trend_code"]=2;}
else if($barom["trend_code"]>0){$barom["trend_desc"]="Rising Slowly";$barom["trend_code"]=1;}
else if($barom["trend_code"]==0){$barom["trend_desc"]="Steady";$barom["trend_code"]=0;}
else if($barom["trend_code"]<0){$barom["trend_desc"]="Falling Slowly";$barom["trend_code"]=-1;}
else if($barom["trend_code"]<-1){$barom["trend_desc"]="Falling";$barom["trend_code"]=-2;}
else if($barom["trend_code"]<-2){$barom["trend_desc"]="Falling Quickly";$barom["trend_code"]=-3;}
else if($barom["trend_code"]<-3){$barom["trend_desc"]="Falling Very Rapidly";$barom["trend_code"]=-4;}
else if($barom["trend_code"]=="N/A"||$barom["trend_code"]==" N/A"||$barom["trend_code"]=="  N/A"||$barom["trend_code"]=="    N/A"){$barom["trend_desc"]="Steady";$barom["trend_code"]=0;}

//dewpoint
$dew["now"] = $data['observations']['dewpoint'] ?? null; 
$dewTrend = "-0.66";
if(is_numeric($dewTrend) != 1 or $dewTrend == '   N/A'){$dew["trend"] = 0;}
else {$dew["trend"] = intval($dewTrend);}
$dew["day_max"] = "12.80";
if ($dew["day_max"] == '   N/A'){$dew["day_max"] = 0;}
$dew["day_maxtime"] = date('H:i',1782811501);
$dew["day_min"] = "10.00";
if ($dew["day_min"] == '   N/A'){$dew["day_min"] = 0;}
$dew["day_mintime"] = date('H:i',1782820780);
$dew["yesterday_max"] = 12.10;
$dew["yesterday_maxtime"] = date('H:i',1782760338);
$dew["yesterday_min"] = 8.70;
$dew["yesterday_mintime"] = date('H:i',1782728860);
$dew["month_max"] = 23.70;
$dew["month_maxtime"] = date('D j H:i',1782308272);
$dew["month_min"] = 4.90;
$dew["month_mintime"] = date('D j H:i',1780946831);
$dew["year_max"] = 23.70;
$dew["year_maxtime"] = date('D j M H:i',1782308272);
$dew["year_min"] = -5.80;
$dew["year_mintime"] = date('D j M H:i',1767670560); 
$dew["alltime_max"] = 23.70;
$dew["alltime_maxtime"] = date('j M Y H:i',1782308272);
$dew["alltime_min"] = -6.10;
$dew["alltime_mintime"] = date('j M Y H:i',1742315520);

// evapotranspiration
$et["current"] = 0.0437;
$et["hour"] = 0.5361;
$et["day"] = 2.1982;
$et["24hr"] = 3.3699;
$et["week"] = 5.3070;
$et["month"] = 96.9219;
$et["year"] = 310.0680;
$et["alltime"] = 866.9810;

// humidity
$humid["now"] = $data['observations']['outHumidity'] ?? null; //weewxrt[3];
$humid["trend"] = -13.32;
if(is_numeric($humid["trend"]) != 1){$humid["trend"] = 0;}
$humid["day_max"] = 86.00;
$humid["day_maxtime"] = date('H:i',1782792039);
$humid["day_min"] = 45.00;
$humid["day_mintime"] = date('H:i',1782822522);
$humid["yesterday_max"] = 94.00;
$humid["yesterday_maxtime"] = date('H:i',1782707434);
$humid["yesterday_min"] = 50.00;
$humid["yesterday_mintime"] = date('H:i',1782735442);
$humid["month_max"] = 99.00;
$humid["month_maxtime"] = date('D j H:i',1780366480);
$humid["month_min"] = 33.00;
$humid["month_mintime"] = date('D j H:i',1782484973);
$humid["year_max"] = 99.00;
$humid["year_maxtime"] = date('D j M H:i',1768493460);
$humid["year_min"] = 20.00;
$humid["year_mintime"] = date('D j M H:i',1777129775);
$humid["alltime_max"] = 99.00;
$humid["alltime_maxtime"] = date('j M Y H:i',1758694200);
$humid["alltime_min"] = 20.00;
$humid["alltime_mintime"] = date('j M Y H:i',1777129775);
$humid["indoors_now"] = $data['observations']['inHumidity'] ?? null; //$weewxrt[23];
$humid["indoors_trend"] = 0.0;
if(is_numeric($humid["indoors_trend"]) != 1){$humid["indoors_trend"] = 0;}
$humid["indoors_day_max"] = 55.00;
$humid["indoors_day_maxtime"] = date('H:i',1782800751);
$humid["indoors_day_min"] = 53.00;
$humid["indoors_day_mintime"] = date('H:i',1782774002);
$humid["indoors_yesterday_max"] = 53.00;
$humid["indoors_yesterday_maxtime"] = date('H:i',1782687604);
$humid["indoors_yesterday_min"] = 50.00;
$humid["indoors_yesterday_mintime"] = date('H:i',1782731506);
$humid["indoors_month_max"] = 72.00;
$humid["indoors_month_maxtime"] = date('D j H:i',1782066586);
$humid["indoors_month_min"] = 50.00;
$humid["indoors_month_mintime"] = date('D j H:i',1781497670);
$humid["indoors_year_max"] = 72.00;
$humid["indoors_year_maxtime"] = date('D j M H:i',1782066586);
$humid["indoors_year_min"] = 35.00;
$humid["indoors_year_mintime"] = date('D j H:i',1767650460);
$humid["indoors_alltime_max"] = 72.00;
$humid["indoors_alltime_maxtime"] = date('j M Y H:i',1782066586);
$humid["indoors_alltime_min"] = 32.00;
$humid["indoors_alltime_mintime"] = date('j M Y H:i',1752517980);


//lightning
$lightning["day_strike_count"] = 0;
$lightning["last_distance"] = 20;
$lightning["last_time"] = 1782184800;
$lightning["hour_strike_count"] = 0;
$lightning["current_strike_count"] = $data["observations"]["lightning_strike_count"] ?? null;
$lightning["month_strike_count"] = 210;
$lightning["year_strike_count"] = 701;
$lightning["alltime_strike_count"] = 2732;
$parts = explode(" ", $lightning["last_time"]);
$parts1 = explode("/", $parts[0]);
$lightning["time_ago"] = time() - strtotime("20" . $parts1[2] . $parts1[1] . $parts1[0] . " " . $parts[1]);

//rainfall
$rain["units"] = " mm";
if($rain["units"] == " mm")
{
$rain["units"] = "mm";
}
else if($rain["units"] == " cm")
{
$rain["units"] = "cm";
}
else if($rain["units"] == " in")
{
$rain["units"] = "in";
}
$rain["rate"] = $data["observations"]["rainRate"] ?? null;
$rain["hour"] = 0.00;
$rain["24hour"] = 0.00;
$rain["yesterday"] = 0.00;
$rain["day"] = 0.00;
$rain["week"] = 0.00;
$rain["month"] = 73.40;
$rain["year"] = 306.70;
if (array_key_exists("stormRain", $data['observations'] ?? []))
{
$rain["event"] =  $data["observations"]["stormRain"] ?? null;
$stormStartTs = $data["observations"]["stormStart"] ?? null;
$rain["storm_start"] = $stormStartTs ? date('H:i D j M', $stormStartTs) : null;
}
else
{
$rain["event"] = $data["observations"]["eventRain"] ?? null;
if(is_numeric($rain["event"]) != 1){$rain["event"] = 0;}
if(is_numeric($p_rain["event"]) != 1){$p_rain["event"] = 0;}
if($rain["event"] > 0 ){
$rain["storm_start"] = date('H:i D j M',($TS)-(0));
}
}

$p_rain["rate"] = $data["observations"]["hailRate"] ?? null;
$p_rain["is_raining"] = ($p_rain["rate"] > 0) ? 1 : 0;
$p_rain["hour"] = 0.00;
$p_rain["24hour"] = 0.00;
$p_rain["yesterday"] = 0.00;
$p_rain["day"] = 0.00;
$p_rain["week"] = 0.00;
$p_rain["month"] = 80.90;
$p_rain["year"] = 337.50;
$p_rain["event"] = $data["observations"]["erain_piezo"] ?? null;
if($p_rain["event"] > 0 ){
$p_rain["storm_start"] = date('H:i D j M',($TS)-(0));
}

// sky
$sky["cloud_base"] = $data['observations']['cloudBase'] ?? null;
$sky["cloud_cover"] = $cloudcover = $data['observations']['cloudcover'] ?? null; 
if(is_numeric($sky["cloud_cover"]) != 1){$sky["cloud_cover"] = 0;}

// solar
$solar["now"] = $data['observations']['radiation'] ?? null; //770.0;
$solar["day_max"] = 1085.6;
$solar["day_maxtime"] = date('H:i',1782825094);
$solar["yesterday_max"] = 1065.8;
$solar["yesterday_maxtime"] = date('H:i',1782744390);
$solar["month_max"] = 1356.1;
$solar["month_maxtime"] = date('D j H:i',1781682473);
$solar["year_max"] = 1769.0;
$solar["year_maxtime"] = date('D j M H:i',1778678929);
$solar["alltime_max"] = 1948.9;
$solar["alltime_maxtime"] = date('j M Y H:i',1751882040);
$solar["lux"] = 97560.0;
$solar["day_lux_max"] = 137540.5;
//sun duration
$solar["threshold"] = 585.9;
$solar["sun_duration_minutes"] = 252.3;
$solar["sun_duration_hours_minutes"] = intdiv($solar["sun_duration_minutes"], 60).' hrs '. ($solar["sun_duration_minutes"] % 60).' mins';
$solar["sunshine_hours_yesterday"] = 199.06324589531548;
$solar["sunshine_minutes_yesterday"] = $solar["sunshine_hours_yesterday"] * 60;
$solar["sunshine_hours_minutes_yesterday"] = intdiv($solar["sunshine_minutes_yesterday"], 60).' hrs '. ($solar["sunshine_minutes_yesterday"] % 60).' mins';
$solar["day_maxtime"] = date('H:i',1782825094);

//temperature
$temp["units"] = "C";
if($temp["units"] == " C")
{
$temp["units"] = "C";
}
else if($temp["units"] == " F")
{
$temp["units"] = "F";
}

// indoor temp 
$temp["indoor_now"] = safeFormat(obsVal('inTemp'), 1); //$weewxrt[22];
$temp["indoor_trend"] = 0.1;
if(is_numeric($temp["indoor_trend"]) != 1){$temp["indoor_trend"] = 0;}
$temp["indoor_day_max"] = 24.10;
$temp["indoor_day_min"] = 23.50;

//feels like indoors
$Temp = $temp["indoor_now"];
$Humidity = $humid["indoors_now"];
$T = $Temp*9/5+32;
$RH = $Humidity;
$HI = 0;
if($T<=40.0){$HI=$T;}
else {$HI=-42.379+(2.04901523*$T)+(10.14333127*$RH)-(0.22475541*$T*$RH)-(0.00683783*$T*$T)-(0.05481717*$RH*$RH)+(0.00122874*$T*$T*$RH)+(0.00085282*$T*$RH*$RH)-(0.00000199*$T*$T*$RH*$RH);}
if ($RH<13&&$T>=80&&$T<=112){$adjust=((13-$RH)/4)*sqrt(17-abs($T-95)/17);$HI=$HI-$adjust;}
else if ($RH>85&&$T>=80&&$T<=87){$adjust=(($RH-85)/10)*((87-$T)/5);$HI=$HI+$adjust;}
else if ($T<80){$HI=0.5*($T+61.0+(($T-68.0)*1.2)+($RH*0.094));}
$temp["indoor_now_feels"] = number_format($HI, 1);
$temp["indoor_now_feels_degC"] = (number_format($HI, 1)-32)*5/9;

//outside temperature
$temp["outside_trend"] = 3.3;
if(is_numeric($temp["outside_trend"]) != 1){$temp["outside_trend"] = 0;}
$temp["outside_now"] = safeFormat(obsVal('outTemp'), 1); //$weewxrt[2];
$temp["apptemp"] = safeFormat(obsVal('apparentTemp'), 1); //$weewxrt[54];
$temp["heatindex"] = $data['observations']['heatIndex'] ?? null; //$weewxrt[41];
$temp["windchill"] = $data['observations']['windChill'] ?? null; //round($weewxrt[24],1);
$temp["humidex"] = $data['observations']['humidex'] ?? null; //$weewxrt[42];
$temp["outside_24h_max"] = 21.00;
$temp["outside_day_avg_60mn"] = 22.59;
$temp["outside_24h_maxtime"] = date('H:i',1782747492);
$temp["outside_24h_min"] = 10.00;
$temp["outside_24h_mintime"] = date('H:i',1782707056);
$temp["outside_yesterday_max"] = 21.00;
$temp["outside_yesterday_maxtime"] = date('H:i',1782747492);
$temp["outside_yesterday_min"] = 10.00;
$temp["outside_yesterday_mintime"] = date('H:i',1782707056);
$temp["outside_day_avg"] = 17.55;
$temp["outside_day_max"] = 23.60;
$temp["outside_day_maxtime"] = date('H:i',1782826155);
$temp["outside_day_min"] = 13.50;
$temp["outside_day_mintime"] = date('H:i',1782792055);
$temp["outside_month_max"] = 34.20;
$temp["outside_month_maxtime"] = date('D j H:i',1782233160);
$temp["outside_month_min"] = 6.10;
$temp["outside_month_mintime"] = date('D j H:i',1780973115);
$temp["outside_year_max"] = 34.20;
$temp["outside_year_maxtime"] = date('D j M H:i',1782233160);
$temp["outside_year_maxtime2"] = date('M',1782233160);
$temp["outside_year_min"] = -3.20;
$temp["outside_year_mintime"] = date('D j M H:i',1767675060);
$temp["outside_year_mintime2"] = date('M',1767675060);
$temp["outside_alltime_max"] = 34.20;
$temp["outside_alltime_maxtime"] = date('j M Y H:i',1782233160);
$temp["outside_alltime_min"] = -3.20;
$temp["outside_alltime_mintime"] = date('j M Y H:i',1767675060);
$temp["outdoor_now_feels"] = $data['observations']['feelslike'] ?? null;
$temp["heatIndex_3hours"] = 19.5;
$temp["appTemp_3hours"] = 19.7;
$temp["windChill_3hours"] = 19.9;
$temp["AvgToday_3hours"] = 19.9;

//uv
$uv["now"] = $data['observations']['UV'] ?? null; //$weewxrt[43];
$uv["day_max"] = 10.0;
$uv["day_maxtime"] = date('H:i',1782825094);
$uv["yesterday_max"] = 9.0;
$uv["yesterday_maxtime"] = date('H:i',1782726731);
$uv["month_max"] = 12.0;
$uv["month_maxtime"] = date('D j H:i',1781260707);
$uv["year_max"] = 15.0;
$uv["year_maxtime"] = date('D j M H:i',1778678920);
$uv["alltime_max"] = 15.0;
$uv["alltime_maxtime"] = date('j M Y H:i',1751882040);

//vpd
$vpd["current"] = $data['observations']['vpd'] ?? null;
if(is_numeric($vpd["current"]) != 1){$vpd["current"] = 0;}
$vpd["day_max"] = 1.4840;
$vpd["day_min"] = 0.2174;
$vpd["day_avg"] = 0.6705;
$vpd["day_maxtime"] = date('H:i',1782822900);
$vpd["day_mintime"] = date('H:i',1782792600);
$vpd["yesterday_max"] = 1.1728;
$vpd["yesterday_min"] = 0.0805;
$vpd["yesterday_avg"] = 0.6570;
$vpd["yesterday_maxtime"] = date('H:i',1782752400);
$vpd["yesterday_mintime"] = date('H:i',1782708300);
$vpd["week_min"] = 0.0805;
$vpd["week_max"] = 1.4840;
$vpd["week_avg"] = 0.6621;
$vpd["week_maxtime"] = date('j M H:i',1782822900);
$vpd["week_mintime"] = date('j M H:i',1782708300);
$vpd["month_max"] = 3.4035;
$vpd["month_min"] = 0.0102;
$vpd["month_avg"] = 0.5544;
$vpd["month_maxtime"] = date('j M H:i',1782486300);
$vpd["month_mintime"] = date('j M H:i',1781145900);
$vpd["year_max"] = 16.9319;
$vpd["year_min"] = 0.0070;
$vpd["year_avg"] = 0.4153;
$vpd["year_maxtime"] = date('j M H:i',1772290200);
$vpd["year_mintime"] = date('j M H:i',1769406000);

//wind
$wind["units"] = " mph"; // m/s or mph or km/h or kts
if ($wind["units"] == " m/s")
{
$wind["units"] = "m/s";
}
else if ($wind["units"] == " mph")
{
$wind["units"] = "mph";
}
else if ($wind["units"] == " km/h")
{
$wind["units"] = "km/h";
}
else if ($wind["units"] == " kts")
{
$wind["units"] = "kts";
}
$wind["direction"] = $data['observations']['windDir'] ?? null; 
$wind["direction_10m_avg"] = $data['observations']['windDir10'] ?? null; //"251.5";
$wind["cardinal"] = $data['observations']['windCardinal'] ?? null;    
$wind["speed"] = $data['observations']['windSpeed'] ?? null; 
$wind["gust"] = $data['observations']['windGust'] ?? null; 
$wind["scaleBft"] = $data['observations']['beaufortScale'] ?? null; //$weewxrt[12];
$wind["descBft"] = $data['observations']['beaufortDesc'] ?? null; //$weewxrt[12];
$wind["speed_avg"] = 1.3;
$wind["speed_max"] = 3.9;
$wind["speed_maxtime"] = date('H:i',1782824700);
$wind["gust_max"] = 11.0;
$wind["gust_maxtime"] = date('H:i',1782824437);
$wind["wind_run"] = 0.3;
$wind["speed_10m_avg"] = 2.8;
$wind["speed_10m_max"] = 3.0;
$wind["gust_10m_max"] = 9.2;
$wind["speed_yesterday_max"] = 4.7;
$wind["speed_yesterday_maxtime"] = date('H:i',1782728700);
$wind["gust_yesterday_max"] = 11.0;
$wind["gust_yesterday_maxtime"] = date('H:i',1782728531);
$wind["speed_month_max"] = 10.3;
$wind["speed_month_maxtime"] = date('M',1780734900);
$wind["gust_month_max"] = 25.5;
$wind["gust_month_maxtime"] = date('D j M H:i',1780739012);
$wind["speed_year_max"] = 26.0;
$wind["speed_year_maxtime"] = "18/02/26 19:34:00";
$wind["gust_year_max"] = 40.0;
$wind["gust_year_maxtime"] = date('D j M H:i',1774456306);
$wind["speed_alltime_max"] = 26.0;
$wind["speed_alltime_maxtime"] = "18/02/26 19:34:00";
$wind["gust_alltime_max"] = 40.0;
$wind["gust_alltime_maxtime"] = date('D j M Y H:i',1774456306);
//include('dvmMeteorShowers.php");
include('dvmColorMap.php');
include('dvmAlmanacData.php');
include('dvmUnitConversions.php'); 
?>