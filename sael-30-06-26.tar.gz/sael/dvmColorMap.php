<?php
// Log errors to file instead of suppressing them or showing on screen
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', '/tmp/weewx_php_errors.log');

// Path to the JSON file - check both relative paths
$jsonFilePath = null;
$jsonCandidates = ['./jsondata/loop.json', '../jsondata/loop.json'];
foreach ($jsonCandidates as $candidate) {
    if (file_exists($candidate)) {
        $jsonFilePath = $candidate;
        break;
    }
}

// Load JSON data with graceful fallback  never die() so index.php can still render
// Note: if included after dvmCombinedData.php, $data is already set; this is a safety net
if (!isset($data) || empty($data)) {
    $data = [];
    if ($jsonFilePath !== null) {
        $jsonData = @file_get_contents($jsonFilePath);
        if ($jsonData !== false) {
            $decoded = json_decode($jsonData, true);
            if ($decoded !== null) {
                $data = $decoded;
            } else {
                error_log("dvmColorMap: Failed to decode JSON from $jsonFilePath: " . json_last_error_msg());
            }
        } else {
            error_log("dvmColorMap: Could not read JSON file at $jsonFilePath");
        }
    } else {
        error_log("dvmColorMap: JSON file not found in ./jsondata/ or ../jsondata/");
    }
}
// Loop Data Colors for weather display
$colorBarometer = $data["observations"]["barometerColor"] ?? null;
$colorBeaufortSpeed = $data["observations"]["beaufortColorSpeed"] ?? null;
$colorBeaufortGust = $data["observations"]["beaufortColorGust"] ?? null;
$colorDewpoint = $data["observations"]["dewpointColor"] ?? null;
$colorFeelsLike = $data["observations"]["feelsLikeColor"] ?? null;
$colorPiezoRain = $data["observations"]["hailColor"] ?? null;
$colorPiezoRainRate = $data["observations"]["hailRateColor"] ?? null;
$colorHeatIndex = $data["observations"]["heatIndexColor"] ?? null;
$colorHumidex = $data["observations"]["humidexColor"] ?? null;
$colorTempIndoors = $data["observations"]["inTempColor"] ?? null;
$colorTempOutside = $data["observations"]["outTempColor"] ?? null;
$colorRadiation = $data["observations"]["radiationColor"] ?? null;
$colorRain = $data["observations"]["rainColor"] ?? null;
$colorRainRate = $data["observations"]["rainRateColor"] ?? null;
$colorUV = $data["observations"]["uvColor"] ?? null;
$colorWetbulbTemp = $data["observations"]["wetbulbTempColor"] ?? null;
$colorWindchill = $data["observations"]["windChillColor"] ?? null;
$colorWindGust = $data["observations"]["windGustColor"] ?? null;
$colorWindSpeed = $data["observations"]["windSpeedColor"] ?? null;

// Archive Data Colors for weather display
// Helper function for temperature color mapping
function getTempColor($temp) {
    if (!isset($temp) || $temp === null) return "#cccccc";
    if ($temp <= -10) return "#8781bd";
    if ($temp <= 0) return "#487ea9";
    if ($temp <= 5) return "#3b9cac";
    if ($temp < 10) return "#9aba2f";
    if ($temp < 20) return "#e6a141";
    if ($temp < 25) return "#ec5a34";
    if ($temp < 30) return "#d05f2d";
    if ($temp < 35) return "#d65b4a";
    if ($temp < 40) return "#dc4953";
    return "#e26870";
}

// Helper function for humidity color mapping
function getHumidityColor($hum) {
    if (!isset($hum) || $hum === null) return "#cccccc";
    if ($hum < 30) return "Blue";
    if ($hum < 60) return "Green";
    return "Red";
}

// Helper function for wind speed color mapping
function getWindColor($speed) {
    if (!isset($speed) || $speed === null) return "#cccccc";
    if ($speed == 0) return "#85a3aa";
    if ($speed == 1) return "#7e98bb";
    if ($speed == 2) return "#6e90d0";
    if ($speed == 3) return "#0f94a7";
    if ($speed == 4) return "#39a239";
    if ($speed == 5) return "#c2863e";
    if ($speed == 6) return "#c8420d";
    if ($speed == 7) return "#d20032";
    if ($speed == 8) return "#af5088";
    if ($speed == 9) return "#754a92";
    if ($speed == 10) return "#45698d";
    if ($speed == 11) return "#c1fc77";
    if ($speed == 12) return "#f1ff6c";
    return "#85a3aa";
}

// Helper function for wind gust color mapping
function getGustColor($gust) {
    if (!isset($gust) || $gust === null) return "#cccccc";
    if ($gust <= 1) return "#85a3aa";
    if ($gust <= 2) return "#7e98bb";
    if ($gust <= 3) return "#6e90d0";
    if ($gust <= 5) return "#0f94a7";
    if ($gust <= 8) return "#39a239";
    if ($gust <= 11) return "#c2863e";
    if ($gust <= 14) return "#c8420d";
    if ($gust <= 17) return "#d20032";
    if ($gust <= 21) return "#af5088";
    if ($gust <= 24) return "#754a92";
    if ($gust <= 28) return "#45698d";
    if ($gust <= 32) return "#c1fc77";
    return "#f1ff6c";
}

// Helper function for lux color mapping
function getLuxColor($lux) {
    if (!isset($lux) || $lux === null) return 'grey';
    if ($lux == 0) return 'grey';
    if ($lux < 16000) return '#89C7E7';
    if ($lux < 32000) return '#ADD8E5';
    if ($lux < 48000) return '#C4EBF1';
    if ($lux < 64000) return '#FFFFC2';
    if ($lux < 80000) return '#FFF684';
    return '#FFD301';
}

// Helper function for zero-rain color
function getZeroRainColor() {
    global $theme;
    return ($theme == 'dark') ? "rgb(59,61,64)" : "#3A3D40";
}

// Air density
$colorAirDensity = "#007fff";

// Barometer almanac
//$colorBarometerCurrent = "#2e8b57";
$colorBarometerDayMax = "#2e8b57";
$colorBarometerDayMin = "#2e8b57";
$colorBarometerYesterdayMax = "#2e8b57";
$colorBarometerYesterdayMin = "#2e8b57";
$colorBarometerMonthMax = "#2e8b57";
$colorBarometerMonthMin = "#007fff";
$colorBarometerYearMax = "#ff6347";
$colorBarometerYearMin = "#f8d747";
$colorBarometerAlltimeMax = "#ff6347";
$colorBarometerAlltimeMin = "#f8d747";

// Temperature colors (current)
//$colorOutTemp = getTempColor($temp["outside_now"] ?? null);
$colorDewpoint = getTempColor($dew["now"] ?? null);
$colorWindchill = getTempColor($temp["windchill"] ?? null);
$colorHeatindex = getTempColor($temp["heatindex"] ?? null);
$colorHumidex = getTempColor($temp["humidex"] ?? null);
$colorAppTemp = getTempColor($temp["apptemp"] ?? null);
$colorOutTempDayAvg = "#eba141";

// Humidity colors
$colorOutHumidity = getHumidityColor($humid["now"] ?? null);
$colorHumidityDayMax = getHumidityColor($humid["day_max"] ?? null);
$colorHumidityDayMin = getHumidityColor($humid["day_min"] ?? null);
$colorHumidityYesterdayMax = getHumidityColor($humid["yesterday_max"] ?? null);
$colorHumidityYesterdayMin = getHumidityColor($humid["yesterday_min"] ?? null);
$colorHumidityMonthMax = getHumidityColor($humid["month_max"] ?? null);
$colorHumidityMonthMin = getHumidityColor($humid["month_min"] ?? null);
$colorHumidityYearMax = getHumidityColor($humid["year_max"] ?? null);
$colorHumidityYearMin = getHumidityColor($humid["year_min"] ?? null);
$colorHumidityAlltimeMax = getHumidityColor($humid["alltime_max"] ?? null);
$colorHumidityAlltimeMin = getHumidityColor($humid["alltime_min"] ?? null);

// Feels like temperature
//$colorFeels = getTempColor($temp["outdoor_now_feels"] ?? null);

// Temperature almanac
$colorOutTempDayMax = "#ec5a34";
$colorOutTempDayMin = "#eba141";
$colorDewpointDayMax = "#eba141";
$colorDewpointDayMin = "#9aba2f";

$colorOutTempYesterdayMax = "#ec5a34";
$colorOutTempYesterdayMin = "#9aba2f";
$colorDewpointYesterdayMax = "#eba141";
$colorDewpointYesterdayMin = "#9aba2f";

$colorOutTempMonthMax = "#d65b4a";
$colorOutTempMonthMin = "#9aba2f";
$colorDewpointMonthMax = "#ec5a34";
$colorDewpointMonthMin = "#369cac";

$colorOutTempYearMax = "#d65b4a";
$colorOutTempYearMin = "#487ea9";
$colorDewpointYearMax = "#ec5a34";
$colorDewpointYearMin = "#487ea9";

$colorOutTempAlltimeMax = "#d65b4a";
$colorOutTempAlltimeMin = "#487ea9";
$colorDewpointAlltimeMax = "#ec5a34";
$colorDewpointAlltimeMin = "#487ea9";

// 60min average
$colorOutTemp60minAvg = "#ec5a34";

// Indoor conditions
$colorInTemp = getTempColor($temp["indoor_now"] ?? null);
$colorInHumidity = getHumidityColor($humid["indoors_now"] ?? null);

// Wind colors
$colorWindSpeedMax = "#7e98bb";
$colorWindGustMax = "#0f94a7";
$colorWindSpeedAvg = "#85a3aa";
$colorWindSpeed10minAvg = "#7e98bb";
$colorWindGust10minMax = "#0f94a7";
$colorWindSpeedYesterdayMax = "#6e90d0";
$colorWindGustYesterdayMax = "#0f94a7";
$colorWindSpeedMonthMax = "#0f94a7";
$colorWindGustMonthMax = "#c8420d";
$colorWindSpeedYearMax = "#c8420d";
$colorWindGustYearMax = "#af5088";
$colorWindSpeedAlltimeMax = "#c8420d";
$colorWindGustAlltimeMax = "#af5088";

// Piezo Rain colors
$colorStormPiezo = "#3a3d40";
if (!isset($p_rain["day"]) || $p_rain["day"] == 0) {
    $colorPiezoDaySum = getZeroRainColor();
} else {
    $colorPiezoDaySum = "#3a3d40";
}
$colorPiezoYesterdaySum = "#3a3d40";
$colorPiezo1hrSum = "#3a3d40";
$colorPiezo24hrSum = "#3a3d40"; 
$colorPiezoMonthSum = "#9f7f3a";
$colorPiezoYearSum = "#cf2848";
$colorPiezoAlltimeSum = "#d476a3";

if (!isset($p_rain["rate"]) || $p_rain["rate"] == 0) {
    $colorPiezoRate = getZeroRainColor();
} else {
    $colorPiezoRate = "#3a3d40";
}
$colorPiezoRateDayMax = "#3a3d40";
$colorPiezoRateYesterdayMax = "#3a3d40";
$colorPiezoRate24hrMax = "#3a3d40"; 
$colorPiezoRateMonthMax = "#0b8c88";
$colorPiezoRateYearMax = "#0b8c88";
$colorPiezoRateAlltimeMax = "#359f35";

// Rain colors
$colorStormRain = "#3a3d40";
if (!isset($rain["day"]) || $rain["day"] == 0) {
    $colorRainDaySum = getZeroRainColor();
} else {
    $colorRainDaySum = "#3a3d40";
}
$colorRainYesterdaySum = "#3a3d40";
$colorRain1hrSum = "#3a3d40";
$colorRain24hrSum = "#3a3d40"; 
$colorRainMonthSum = "#a79d51";
$colorRainYearSum = "#cf2848";
$colorRainAlltimeSum = "#d476a3";

if (!isset($rain["rate"]) || $rain["rate"] == 0) {
    $colorRainRate = getZeroRainColor();
} else {
    $colorRainRate = "#3a3d40";
}
$colorRainRateDayMax = "#3a3d40";
$colorRainRateYesterdayMax = "#3a3d40";
$colorRainRate24hrMax = "#3a3d40"; 
$colorRainRateMonthMax = "#9f7f3a";
$colorRainRateYearMax = "#be4c07";
$colorRainRateAlltimeMax = "#be4c07";

// UV colors
$colorUVCurrent = "#fd8620";
$colorUVDayMax = "#fb1215";
$colorUVYesterdayMax = "#fb1215";
$colorUVMonthMax = "#de257b";
$colorUVYearMax = "#de257b";
$colorUVAlltimeMax = "#de257b";

// Solar/Radiation colors
$colorSolarCurrent = "#ffa242";
$colorSolarDayMax = "#fd8b17";
$colorSolarYesterdayMax = "#fd8b17";
$colorSolarMonthMax = "#ff7400";
$colorSolarYearMax = "grey";
$colorSolarAlltimeMax = "grey";

$colorLuxCurrent = getLuxColor($solar["lux"] ?? null);
$colorLuxDay = getLuxColor($solar["day_lux_max"] ?? null);
?>