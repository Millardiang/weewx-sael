<?php

//data for solar energy module
$battery["power"] = -8;
$battery["soc"] = 100;
$grid["power"] = -2208;
$load["total_power"] = 1;
$solar["power"] = 2514;
$solar["daily_export"] = 14.38;
$solar["daily_energy"] = 17.19;

include("customSettings.php");
?>